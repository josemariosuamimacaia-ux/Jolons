var C = JSON.parse(document.getElementById('cfg').textContent), log = document.getElementById('log'), inp = document.getElementById('t');
var vistas = 0, hum = false, ocupado = false, timer = null, base = '/chat/' + C.slug, sug = null;

function sid() {
  try {
    var k = 'mt_' + C.slug, s = localStorage.getItem(k);
    if (!s) {
      s = (window.crypto && crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2) + Date.now()).replace(/[^A-Za-z0-9-]/g, '');
      localStorage.setItem(k, s);
    }
    return s;
  } catch (e) { return window.__s || (window.__s = String(Math.random()).slice(2) + String(Date.now())); }
}
var S = sid();

function add(txt, cls) {
  var d = document.createElement('div'); d.className = 'm ' + cls;
  if (cls === 'human') { var s = document.createElement('small'); s.textContent = 'equipa'; d.appendChild(s); }
  d.appendChild(document.createTextNode(txt)); log.appendChild(d); log.scrollTop = log.scrollHeight; return d;
}
function mostrar(ms) {
  ms.forEach(function (m) {
    if (m.id > vistas) vistas = m.id;
    add(m.conteudo, m.remetente === 'user' ? 'me' : m.remetente === 'human' ? 'human' : 'assistant');
  });
}
function parar() { if (timer) { clearInterval(timer); timer = null; } }
function poll() {
  fetch(base + '/mensagens?sessao=' + S + '&desde=' + vistas).then(function (r) { return r.json(); })
    .then(function (j) { mostrar(j.mensagens || []); hum = !!j.humano; if (!hum) parar(); }).catch(function () {});
}
function iniciar() { if (!timer) timer = setInterval(poll, 4000); }

// Perguntas sugeridas para o cliente começar a conversa
function sugestoes() {
  sug = document.createElement('div'); sug.className = 'sug';
  ['Que produtos ou serviços têm?', 'Qual é o horário?', 'Quero falar com uma pessoa'].forEach(function (t) {
    var b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = t;
    b.onclick = function () { enviar(t); }; sug.appendChild(b);
  });
  log.appendChild(sug);
}
function saudacao() { add('Olá! Sou o assistente da ' + C.nome + '. Como posso ajudar?', 'assistant'); sugestoes(); }

function enviar(t) {
  t = t.trim(); if (!t || ocupado) return;
  if (sug) { sug.remove(); sug = null; }
  add(t, 'me'); ocupado = true;
  var w = hum ? null : add('…', 'assistant');
  fetch(base + '/mensagem', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessao: S, texto: t }) })
    .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, j: j }; }); })
    .then(function (x) {
      if (w) w.remove();
      if (!x.ok) { add(x.j.erro || 'Não foi possível enviar. Tenta de novo.', 'assistant'); }
      else { mostrar(x.j.mensagens || []); hum = !!x.j.humano; if (hum) iniciar(); }
    })
    .catch(function () { if (w) w.remove(); add('Sem ligação. Tenta de novo.', 'assistant'); })
    .then(function () { ocupado = false; });
}

fetch(base + '/mensagens?sessao=' + S + '&desde=0&tudo=1').then(function (r) { return r.json(); }).then(function (j) {
  var ms = j.mensagens || [];
  if (ms.length) { mostrar(ms); hum = !!j.humano; if (hum) iniciar(); } else saudacao();
}).catch(saudacao);

document.getElementById('f').onsubmit = function (e) { e.preventDefault(); var t = inp.value; inp.value = ''; enviar(t); };

(function () {
  var K = sessionStorage.getItem('mt_admin') || '', tm = null;
  function $(i) { return document.getElementById(i); }
  function h(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function erro(x) { alert(x.message); }

  // Pedido à API com a chave de administração
  function api(m, u, b) {
    return fetch(u, { method: m, headers: { 'X-API-Key': K, 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (r.status === 401) { sair(); throw new Error('Chave errada'); }
          if (!r.ok) throw new Error(j.erro || ('Erro ' + r.status));
          return j;
        });
      });
  }
  function mostrar(logado) { $('entrar').hidden = logado; $('painel').hidden = !logado; $('sair').hidden = !logado; }
  function sair() { sessionStorage.removeItem('mt_admin'); K = ''; clearInterval(tm); mostrar(false); }
  function iniciar() { mostrar(true); carregarEmpresas(); carregarHumanos(); carregarConversas(); carregarSemResposta(); clearInterval(tm); tm = setInterval(carregarHumanos, 15000); }

  $('fl').onsubmit = function (e) {
    e.preventDefault(); K = $('k').value.trim();
    api('GET', '/api/empresas').then(function () {
      sessionStorage.setItem('mt_admin', K); $('k').value = ''; $('ml').textContent = ''; iniciar();
    }).catch(function (x) { $('ml').textContent = x.message; });
  };
  $('sair').onclick = sair;

  function carregarEmpresas() {
    Promise.all([api('GET', '/api/empresas'), api('GET', '/api/estatisticas?dias=7')]).then(function (r) {
      var st = {}; r[1].empresas.forEach(function (s) { st[s.empresa] = s; });
      var L = $('lista'); L.textContent = '';
      if (!r[0].empresas.length) { L.appendChild(h('p', 'msg', 'Ainda não há empresas. Regista a primeira acima.')); return; }
      r[0].empresas.forEach(function (e) {
        var c = h('div', 'item');
        c.appendChild(h('b', null, e.nome + ' '));
        var fim = e.estado === 'teste' && e.teste_ate ? ' até ' + new Date(e.teste_ate).toLocaleString('pt-PT') : '';
        c.appendChild(h('span', 'badge' + (e.ativa ? '' : ' off'), e.estado + fim));
        var s = st[e.nome];
        if (s) c.appendChild(h('p', 'msg', 'Últimos 7 dias: ' + s.pessoas + ' pessoas · ' + s.mensagens_clientes + ' mensagens · ' + s.contactos_recolhidos + ' contactos · ' + s.perguntas_sem_resposta + ' sem resposta'));
        var b = h('div', 'row');
        if (e.chat_url) {
          var url = location.origin + e.chat_url, p = h('p', 'msg'), a = h('a', null, url);
          a.href = url; a.target = '_blank'; a.rel = 'noopener'; p.appendChild(a); c.appendChild(p);
          var cp = h('button', 'btn', 'Abrir chat'); cp.type = 'button';
          cp.onclick = function () { window.open(url, '_blank'); }; b.appendChild(cp);
          var cc = h('button', 'btn alt', 'Copiar link'); cc.type = 'button';
          cc.onclick = function () { try { navigator.clipboard.writeText(url); cc.textContent = 'Copiado'; } catch (x) { prompt('Copia o link:', url); } };
          b.appendChild(cc);
        }
        [['Ativar (pagou)', 'ativo'], ['Suspender', 'suspenso'], ['+2 dias de teste', 'teste']].forEach(function (x) {
          var bt = h('button', 'btn alt', x[0]); bt.type = 'button';
          bt.onclick = function () { api('POST', '/api/empresas/' + e.id + '/estado', { estado: x[1], dias: 2 }).then(carregarEmpresas).catch(erro); };
          b.appendChild(bt);
        });
        c.appendChild(b); L.appendChild(c);
      });
    }).catch(function (x) { $('lista').textContent = x.message; });
  }

  function carregarHumanos() {
    api('GET', '/api/conversas-humano').then(function (j) {
      var L = $('humanos');
      if (L.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return; // não interromper quem está a escrever
      L.textContent = '';
      if (!j.conversas.length) { L.appendChild(h('p', 'msg', 'Nenhuma conversa à espera.')); return; }
      j.conversas.forEach(function (c) {
        var d = h('div', 'item'), num = c.cliente_numero.length > 14 ? c.cliente_numero.slice(0, 8) + '…' : c.cliente_numero;
        d.appendChild(h('b', null, (c.empresa || '?') + ' · ' + num + ' · ' + (c.phone_number_id === 'web' ? 'chat web' : 'WhatsApp')));
        d.appendChild(h('p', 'msg', 'Última mensagem (' + c.ultimo_remetente + '): ' + (c.ultima_mensagem || '')));
        var f = h('form', 'row'), i = h('input'), s = h('button', 'btn', 'Enviar');
        i.placeholder = 'Resposta para o cliente'; i.setAttribute('aria-label', 'Resposta'); s.type = 'submit';
        f.appendChild(i); f.appendChild(s);
        f.onsubmit = function (ev) {
          ev.preventDefault(); var t = i.value.trim(); if (!t) return;
          api('POST', '/api/responder-humano', { phone_number_id: c.phone_number_id, cliente_numero: c.cliente_numero, texto: t })
            .then(function () { i.value = ''; alert('Enviado.'); }).catch(erro);
        };
        var dv = h('button', 'btn alt', 'Devolver à IA'); dv.type = 'button';
        dv.onclick = function () { api('POST', '/api/devolver-ia', { phone_number_id: c.phone_number_id, cliente_numero: c.cliente_numero }).then(carregarHumanos).catch(erro); };
        d.appendChild(f); d.appendChild(dv); L.appendChild(d);
      });
    }).catch(function () {});
  }

  // Formulário: monta o texto que a IA vai usar e regista a empresa
  function v(i) { return $(i).value.trim(); }
  $('ex').onclick = function () {
    $('en').value = 'Loja Demo'; $('es').value = 'loja de tecnologia';
    $('ed').value = 'Vende telemóveis, portáteis e acessórios.';
    $('epd').value = 'Portátil Pro 14: 16 GB de RAM, SSD de 512 GB, bateria até 12 h\nTelemóvel Lite 5G: 128 GB, câmara de 50 MP, dual SIM\nAuscultadores Air: Bluetooth, cancelamento de ruído, 30 h de autonomia';
    $('eho').value = 'Segunda a sábado, 8h às 18h'; $('elo').value = 'Luanda';
    $('epo').value = 'Garantia de 1 ano nos equipamentos.'; $('eex').value = '';
  };
  $('fe').onsubmit = function (ev) {
    ev.preventDefault();
    var pr = v('en') + (v('es') ? ' (' + v('es') + ')' : '') + '. ' + v('ed') + '\nProdutos e serviços:\n' +
      v('epd').split('\n').filter(Boolean).map(function (l) { return '- ' + l; }).join('\n') +
      (v('eho') ? '\nHorário: ' + v('eho') : '') + (v('elo') ? '\nContactos e localização: ' + v('elo') : '') +
      (v('epo') ? '\nGarantia, entrega e pagamento: ' + v('epo') : '') + (v('eex') ? '\nRegras extra: ' + v('eex') : '');
    api('POST', '/api/empresas', { nome: v('en'), system_prompt: pr, humano_ativo: $('eh').checked }).then(function (j) {
      $('me').textContent = 'Empresa registada. Chat: ' + location.origin + j.chat_url + ' (tem 2 dias de teste).';
      $('fe').reset(); $('eh').checked = true; carregarEmpresas();
    }).catch(function (x) { $('me').textContent = x.message; });
  };

  // Testar o sistema (base de dados, chave e crédito da IA, modelo)
  $('dg').onclick = function () {
    var R = $('dgr'); R.textContent = 'A testar…';
    api('POST', '/api/diagnostico').then(function (j) {
      R.textContent = '';
      [['Base de dados', j.base_de_dados ? 'OK' : 'PROBLEMA'],
       ['IA (' + j.modelo + ')', (j.ia.ok ? 'OK. ' : 'PROBLEMA: ') + j.ia.mensagem],
       ['WhatsApp', j.whatsapp_configurado ? 'configurado' : 'não configurado (normal se só usas o chat web)']
      ].forEach(function (l) { R.appendChild(h('p', 'msg', l[0] + ': ' + l[1])); });
    }).catch(function (x) { R.textContent = x.message; });
  };

  // Conversas recentes e leitura de uma conversa
  function carregarConversas() {
    api('GET', '/api/conversas?limite=20').then(function (j) {
      var L = $('conversas'); L.textContent = '';
      if (!j.conversas.length) { L.appendChild(h('p', 'msg', 'Ainda não há conversas.')); return; }
      j.conversas.forEach(function (c) {
        var d = h('div', 'item');
        d.appendChild(h('b', null, (c.empresa || '?') + ' · ' + c.canal + ' · ' + c.mensagens + ' mensagens' + (c.humano_assumiu ? ' · à espera de pessoa' : '')));
        if (c.contacto) d.appendChild(h('p', 'msg', 'Contacto: ' + c.contacto));
        d.appendChild(h('p', 'msg', c.ultima_mensagem || ''));
        var b = h('button', 'btn alt', 'Ver conversa'); b.type = 'button'; b.onclick = function () { verConversa(c.id); };
        d.appendChild(b); L.appendChild(d);
      });
    }).catch(function () {});
  }
  function verConversa(id) {
    api('GET', '/api/conversas/' + id).then(function (j) {
      var T = $('transc'); T.textContent = ''; T.appendChild(h('h2', null, 'Conversa'));
      j.mensagens.forEach(function (m) {
        var quem = m.remetente === 'user' ? 'Cliente' : m.remetente === 'human' ? 'Equipa' : 'Bot';
        T.appendChild(h('p', 'msg', quem + ': ' + m.conteudo + (m.sem_resposta ? '  (o bot não soube responder)' : '')));
      });
      T.scrollIntoView();
    }).catch(erro);
  }
  function carregarSemResposta() {
    api('GET', '/api/sem-resposta?dias=30').then(function (j) {
      var L = $('semresp'); L.textContent = '';
      if (!j.perguntas.length) { L.appendChild(h('p', 'msg', 'Nenhuma pergunta sem resposta. Bom sinal.')); return; }
      j.perguntas.forEach(function (p) { L.appendChild(h('p', 'msg', (p.empresa || '?') + ': ' + p.pergunta)); });
    }).catch(function () {});
  }
  $('csv').onclick = function () {
    fetch('/api/exportar.csv', { headers: { 'X-API-Key': K } })
      .then(function (r) { if (!r.ok) throw new Error('Erro ' + r.status); return r.blob(); })
      .then(function (b) {
        var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'mactech_conversas.csv';
        document.body.appendChild(a); a.click(); a.remove();
      }).catch(erro);
  };

  if (K) { api('GET', '/api/empresas').then(iniciar).catch(function () { mostrar(false); }); } else { mostrar(false); }
})();

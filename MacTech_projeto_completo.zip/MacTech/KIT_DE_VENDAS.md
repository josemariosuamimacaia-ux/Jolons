# MacTech — kit de vendas para hoje

## 1. Como funciona este tipo de produto (pesquisa)
Li guias e páginas de vários serviços de atendimento com IA para WhatsApp e chat de 2026. O que se repete:

**O que os clientes esperam**
- Respostas 24 horas, curtas, sem inventar.
- **Captar contactos**: o bot pede nome e telefone a quem quer comprar.
- **Passar a uma pessoa**, com a conversa à vista. As situações de reclamação e de compra grande devem ir sempre para uma pessoa.
- **Relatórios**: quantas pessoas entraram, quantas pediram uma pessoa e **que perguntas o bot não soube responder**.
- Conversas guardadas e exportáveis.
- Testar antes de ligar: erros de escrita, preços, clientes zangados e pedidos de pessoa.

**Como cobram**
- Subscrição mensal por número de bots ou de mensagens. Em sites estrangeiros vi planos de cerca de **29 a 199 dólares por mês** (Starter, Pro e Business). São referências de outros países, não de Angola.
- Alguns cobram por mensagem. No WhatsApp oficial, a Meta cobra à parte.

**O que acontece depois de programar (o trabalho real)**
1. Recolher a informação da empresa.
2. Definir quando o bot passa a uma pessoa.
3. Testar com perguntas reais.
4. Pôr a funcionar.
5. Ver todas as semanas as "perguntas sem resposta" e melhorar o catálogo. É isto que faz o cliente ficar.

## 2. O que a MacTech já tem
Respostas com IA a partir do catálogo, chat web com link, passagem a humano, contactos recolhidos, perguntas sem resposta, estatísticas, exportação em CSV, 2 dias de teste e painel para gerir tudo.

## 3. Preparar a demonstração (cerca de 20 minutos por negócio)
Pergunta ao dono do negócio:
1. Que produtos ou serviços vendem, com detalhes (tamanhos, tipos, o que inclui)?
2. Qual é o horário e onde ficam?
3. Que perguntas os clientes fazem mais?
4. Como se paga, e há entrega ou garantia?
5. Quando querem que uma pessoa assuma a conversa?

Depois, no painel: regista a empresa, abre o link do chat e testa 10 perguntas, incluindo uma com erros de escrita, uma reclamação e "quero falar com uma pessoa". Grava a tela do telemóvel (30 a 60 segundos).

## 4. Mensagem para enviar
> Olá! Somos a MacTech, um projeto novo que cria assistentes de atendimento com IA. Preparei uma demonstração com os produtos da [NOME DO NEGÓCIO]: o assistente responde aos clientes a qualquer hora e passa a conversa a uma pessoa quando é preciso. Posso mostrar-lhe em 2 minutos? Se gostar, pode experimentar 2 dias sem pagar nada.

**Guião de 1 minuto:** problema (clientes que escrevem fora de horas e ficam sem resposta), demonstração (mostra o vídeo ou o chat), teste de 2 dias, próximo passo ("que perguntas os seus clientes fazem mais?").

## 5. A oferta e o preço
- **2 dias de teste grátis.** Depois, só continua quem gostar.
- **Como calcular o preço:** (custo da IA por conversa × número de conversas por mês) + o teu tempo para manter o catálogo + uma margem. Mede o custo real na primeira semana antes de fixares um valor.
- **No início, usa um preço piloto baixo** para conseguir os primeiros clientes e depoimentos. Sobe depois.
- Não prometas resultados que não podes garantir. Diz o que o bot faz hoje.

## 6. Objeções e respostas
- **"E se o bot disser asneiras?"** Só responde com o que a empresa lhe deu. Se não souber, pede o contacto e chama uma pessoa. E há 2 dias para testar.
- **"Não tenho tempo para configurar."** Eu trato disso: só preciso de 20 minutos de conversa consigo.
- **"Os clientes preferem pessoas."** Por isso, quem pede uma pessoa passa logo para si. O bot só atende o que é repetido.
- **"É caro?"** Compara com o custo de perder clientes que escrevem fora de horas.

## 7. Honestidade e responsabilidade
- Diz sempre que a MacTech é um projeto novo. Não digas que és uma empresa registada se não és.
- Avisa que o cliente fala com uma IA. O chat já mostra isso.
- **Antes de cobrar dinheiro, um adulto responsável tem de assinar o acordo e receber os pagamentos** (por exemplo, o teu tio). Durante o teste grátis podes mostrar e testar à vontade.

## 8. Checklist de arranque de um cliente
- [ ] Catálogo completo registado
- [ ] 10 perguntas testadas, incluindo reclamação e "falar com uma pessoa"
- [ ] Link do chat entregue (e QR code, se quiserem)
- [ ] Combinado quem responde quando o bot passa a conversa
- [ ] Data do fim dos 2 dias anotada
- [ ] Revisão das "perguntas sem resposta" ao fim de uma semana
